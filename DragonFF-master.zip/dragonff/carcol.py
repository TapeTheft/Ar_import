from gtaLib import dff

def do_stuff (path):
    veh = dff.DffFile ()
    veh.load_file (path)

    body_has_prim = False
    has_prim = False
    body_has_sec = False
    has_sec = False

    clump = veh.clumps[0]
    for atomic in clump.atomic_list:
        geometry = clump.geometry_list[atomic.geometry]
        frame = clump.frame_list[atomic.frame]

        for material in geometry.materials:
            if list(material.color) == [60, 255, 0, 255]:
                has_prim = True
                if frame.name == "chassis_hi":
                    body_has_prim = True
            elif list(material.color) == [255, 0, 175, 255]:
                has_sec = True
                if frame.name == "chassis_hi":
                    body_has_sec = True

    print(path.split("/")[-1].split(".")[0], body_has_prim, has_prim, body_has_sec, has_sec)

vehicles = [
    "landstal.dff",
    "idaho.dff",
    "stinger.dff",
    "linerun.dff",
    "peren.dff",
    "sentinel.dff",
    "patriot.dff",
    "firetruk.dff",
    "trash.dff",
    "stretch.dff",
    "manana.dff",
    "infernus.dff",
    "blista.dff",
    "pony.dff",
    "mule.dff",
    "cheetah.dff",
    "ambulan.dff",
    "fbicar.dff",
    "moonbeam.dff",
    "esperant.dff",
    "taxi.DFF",
    "kuruma.dff",
    "bobcat.dff",
    "mrwhoop.dff",
    "bfinject.dff",
    "corpse.dff",
    "police.DFF",
    "enforcer.dff",
    "securica.dff",
    "banshee.dff",
    "predator.dff",
    "bus.dff",
    "rhino.dff",
    "barracks.dff",
    "train.dff",
    "chopper.dff",
    "dodo.dff",
    "coach.dff",
    "cabbie.dff",
    "stallion.dff",
    "rumpo.dff",
    "rcbandit.dff",
    "bellyup.dff",
    "mrwongs.dff",
    "mafia.dff",
    "yardie.dff",
    "yakuza.dff",
    "diablos.dff",
    "columb.dff",
    "hoods.dff",
    "airtrain.dff",
    "deaddodo.dff",
    "speeder.dff",
    "reefer.dff",
    "panlant.dff",
    "flatbed.dff",
    "yankee.dff",
    "escape.dff",
    "borgnine.dff",
    "toyz.dff",
    "ghost.dff",
]

for veh in vehicles:
    do_stuff ("/home/parik/Data/IIIIMG/" + veh)
