from gtaLib import dff
import struct

dffFile = dff.dff()
dffFile.load_file("/home/parik/Data/VCIMG/coach.dff")

for geometry in dffFile.geometry_list:
    prev_tri = geometry.triangles[0].material
    for triangle in geometry.triangles:
        a = geometry.vertices[triangle.a]
        b = geometry.vertices[triangle.b]
        c = geometry.vertices[triangle.c]

        center = ((a.x + b.x + c.x) / 3,
                  (a.y + b.y + c.y) / 3,
                  (a.z + b.z + c.z) / 3)

        print(center[0] ** 2 + center[1] ** 2 + center[2] ** 2)


    print("=======================================================")
