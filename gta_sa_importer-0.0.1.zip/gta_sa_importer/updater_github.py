# gta_sa_importer/updater_github.py
import bpy, os, sys, json, tempfile, shutil, zipfile, importlib, time
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

# === НАСТРОЙ: владелец/репозиторий и имя zip-ассета ===
GITHUB_OWNER = "Cheliks"         # <- поменяй
GITHUB_REPO  = "gta_sa_importer" # <- поменяй
ASSET_PREFIX = "gta_sa_importer" # архив вида gta_sa_importer-0.6.4.zip

API_BASE = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}"

# Optional: use a plain-text update manifest (INI-like) hosted anywhere (e.g. GitHub raw)
# Example contents:
#   version: (0, 6, 5)
#   zip: https://github.com/OWNER/REPO/releases/download/v0.6.5/gta_sa_importer-0.6.5.zip
UPDATE_INI_URL = ""  # e.g. "https://raw.githubusercontent.com/user/repo/branch/update.ini"

def _get_text(url, timeout=10):
    req = Request(url, headers={"User-Agent":"Blender-GTA-SA-Updater"})
    with urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "ignore")

def _parse_update_ini(txt: str):
    """Return dict with 'version' (tuple) and optional 'zip' URL."""
    ver = None; zip_url = None
    for line in txt.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        if s.lower().startswith("version"):
            vraw = s.split(":", 1)[1].strip()
            vraw = vraw.strip().strip("()").replace(",", ".").replace(" ", "")
            parts = [p for p in vraw.split(".") if p.isdigit()]
            while len(parts) < 3: parts.append("0")
            try:
                ver = tuple(int(p) for p in parts[:3])
            except Exception:
                pass
        elif s.lower().startswith("zip"):
            zip_url = s.split(":", 1)[1].strip()
    return {"version": ver, "zip": zip_url}

# --- утилиты версии ---
def _parse_version_tuple(tup_or_str):
    if isinstance(tup_or_str, tuple):
        return tup_or_str
    s = str(tup_or_str).strip().lstrip("vV")
    parts = [int(p) for p in s.replace("-", ".").split(".") if p.isdigit()]
    while len(parts) < 3: parts.append(0)
    return tuple(parts[:3])

def _version_gt(a, b):
    return _parse_version_tuple(a) > _parse_version_tuple(b)

# --- сетевые вызовы ---
def _get_json(url, timeout=10):
    req = Request(url, headers={"User-Agent":"Blender-GTA-SA-Updater"})
    with urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "ignore"))

def _pick_release(allow_prerelease=False):
    if allow_prerelease:
        # взять самую свежую среди всех
        arr = _get_json(f"{API_BASE}/releases")
        if not arr: return None
        # отсортируем по created_at/ published_at
        arr.sort(key=lambda x: x.get("created_at") or x.get("published_at") or "", reverse=True)
        return arr[0]
    else:
        return _get_json(f"{API_BASE}/releases/latest")

def _pick_asset(release):
    assets = release.get("assets") or []
    # выбрать zip-ассет по префиксу
    for a in assets:
        nm = a.get("name") or ""
        if nm.endswith(".zip") and nm.startswith(ASSET_PREFIX):
            return a
    # если не нашли — возьмём первый .zip
    for a in assets:
        nm = a.get("name") or ""
        if nm.endswith(".zip"):
            return a
    return None

def _download(url, out_path, timeout=60):
    req = Request(url, headers={"User-Agent":"Blender-GTA-SA-Updater"})
    with urlopen(req, timeout=timeout) as r, open(out_path, "wb") as f:
        shutil.copyfileobj(r, f)

# --- пути аддона ---
def _addon_dir():
    return os.path.dirname(os.path.abspath(__file__))

def _addons_root():
    # .../Blender/4.x/scripts/addons
    return os.path.dirname(_addon_dir())

def _module_name():
    # имя папки = имя модуля
    return os.path.basename(_addon_dir())

# --- установка обновления ---
def _install_zip(zip_path):
    root = _addons_root()
    modname = _module_name()
    tmp_extract = tempfile.mkdtemp(prefix="gtasa_upd_")
    try:
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(tmp_extract)
        # найдём папку с именем модуля
        candidate = os.path.join(tmp_extract, modname)
        if not os.path.isdir(candidate):
            # если в зипе верхняя папка отличается — возьмём первую директорию
            subs = [d for d in os.listdir(tmp_extract) if os.path.isdir(os.path.join(tmp_extract, d))]
            if subs:
                candidate = os.path.join(tmp_extract, subs[0])
        if not os.path.isdir(candidate):
            raise RuntimeError("В архиве не найдена корневая папка аддона")

        dst = os.path.join(root, modname)
        backup = dst + ".bak"

        # выключим аддон, чтобы файлы не держались открытыми
        try:
            bpy.ops.preferences.addon_disable(module=modname)
        except Exception:
            pass

        # бэкап
        if os.path.isdir(backup):
            shutil.rmtree(backup, ignore_errors=True)
        if os.path.isdir(dst):
            os.rename(dst, backup)

        # установка новой версии
        shutil.copytree(candidate, dst)

        # удалим бэкап при успехе (или оставь — как хочешь)
        shutil.rmtree(backup, ignore_errors=True)
        return True
    finally:
        shutil.rmtree(tmp_extract, ignore_errors=True)

def _reload_addon():
    modname = _module_name()
    try:
        bpy.ops.preferences.addon_enable(module=modname)
    except Exception:
        # fallback на ручной reload
        if modname in sys.modules:
            importlib.reload(sys.modules[modname])

# --- публичный API модуля ---
def check_latest(current_version_tuple, allow_prerelease=False):
    """Возвращает dict: {'has_update':bool, 'online_version':(x,y,z), 'release':dict, 'asset':dict or None}"""
    if UPDATE_INI_URL:
        try:
            ini_txt = _get_text(UPDATE_INI_URL)
            meta = _parse_update_ini(ini_txt)
            ini_ver = meta.get("version")
            if ini_ver and _version_gt(ini_ver, current_version_tuple):
                asset = None
                zip_url = meta.get("zip")
                if zip_url:
                    asset = {"browser_download_url": zip_url, "name": zip_url.rsplit("/",1)[-1]}
                return {"has_update": True, "online_version": ini_ver, "release": {"source":"ini"}, "asset": asset}
        except Exception:
            pass
    rel = _pick_release(allow_prerelease=allow_prerelease)
    if not rel: 
        return {"has_update": False, "online_version": None, "release": None, "asset": None}
    tag = rel.get("tag_name") or rel.get("name") or ""
    online_ver = _parse_version_tuple(tag)
    has_update = _version_gt(online_ver, current_version_tuple)
    asset = _pick_asset(rel) if has_update else None
    return {"has_update": has_update, "online_version": online_ver, "release": rel, "asset": asset}

def perform_update(asset):
    """Скачивает и ставит ZIP-ассет, затем перегружает аддон. Возвращает True/False."""
    if not asset: 
        return False
    url = asset.get("browser_download_url")
    if not url: 
        return False
    tmp_zip = tempfile.mktemp(prefix="gtasa_dl_", suffix=".zip")
    _download(url, tmp_zip)
    ok = _install_zip(tmp_zip)
    try: os.remove(tmp_zip)
    except Exception: pass
    if ok:
        _reload_addon()
    return ok
