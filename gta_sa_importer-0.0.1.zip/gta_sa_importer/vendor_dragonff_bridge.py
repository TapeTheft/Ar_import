
# -*- coding: utf-8 -*-
"""
DragonFF vendor bridge for gta_sa_importer.

Primary mode (preferred): fully delegate the DFF import to DragonFF (installed in Blender)
with Read Material Split forced ON, using DFF/TXD extracted from IMG. This avoids any
guessing and uses DragonFF's material pipeline end-to-end.

Fallback mode: if DragonFF is unavailable or extraction fails, fall back to original importer.
"""
from __future__ import annotations

import bpy, os, tempfile, shutil, contextlib
from typing import List, Tuple

# Import our own IMG helpers
try:
    from .lib import img as _imglib
except Exception:
    _imglib = None

def _dragonff_available() -> bool:
    return hasattr(bpy.ops, "import_scene") and hasattr(bpy.ops.import_scene, "dff")

@contextlib.contextmanager
def _temp_dir():
    d = tempfile.mkdtemp(prefix="gtasa_vendor_")
    try:
        yield d
    finally:
        try:
            shutil.rmtree(d, ignore_errors=True)
        except Exception:
            pass

def _guess_paths(root: str, model_name: str, category: str, outdir: str) -> tuple[str | None, list[str]]:
    """
    Extract DFF/TXD from IMG archives to outdir.
    Returns (dff_path, txd_paths)
    """
    if _imglib is None:
        return (None, [])
    img_candidates = []
    if category == "vehicles":
        img_candidates = [f"models/{x}" for x in ("vehs.img","vehs_1.img","vehs_2.img","vehs_3.img","vehs_4.img","vehs_5.img","vehs_6.img","vehs_7.img")]
    elif category == "gamemods":
        img_candidates = ["models/gamemods.img"]
    else:
        img_candidates = ["models/accessories.img", "models/gta3.img", "models/gta_int.img"]
    dff_name = model_name + ".dff"
    txd_name = model_name + ".txd"
    dff_path = None
    txd_paths = []
    for rel in img_candidates:
        full = os.path.join(root, rel)
        if not os.path.isfile(full):
            continue
        try:
            with _imglib.IMG.open(full) as imgf:
                if dff_path is None and dff_name in imgf:
                    p = os.path.join(outdir, dff_name)
                    with open(p, "wb") as w, imgf.open(dff_name) as r:
                        w.write(r.read())
                    dff_path = p
                if txd_name in imgf:
                    p = os.path.join(outdir, txd_name)
                    if not os.path.exists(p):
                        with open(p, "wb") as w, imgf.open(txd_name) as r:
                            w.write(r.read())
                    txd_paths.append(p)
        except Exception:
            continue
    if category == "vehicles":
        generic_vehicle_txd = os.path.join(root, "models", "generic", "vehicle.txd")
        if os.path.isfile(generic_vehicle_txd):
            gv = os.path.join(outdir, "vehicle.txd")
            try:
                shutil.copy2(generic_vehicle_txd, gv)
                txd_paths.append(gv)
            except Exception:
                pass
    return (dff_path, txd_paths)

def vendor_import_via_dragonff(context, model_name: str, category: str) -> bool:
    """Return True if handled fully via DragonFF (skip our importer)."""
    if not _dragonff_available():
        return False
    s = getattr(context.scene, "gtasa_settings", None)
    root = getattr(s, "game_root", "") if s else ""
    if not root or not os.path.isdir(root):
        return False
    with _temp_dir() as tmp:
        dff_path, txd_paths = _guess_paths(root, model_name, category, tmp)
        if not dff_path:
            return False
        files = [{"name": os.path.basename(dff_path)}] + [{"name": os.path.basename(p)} for p in txd_paths]
        try:
            res = bpy.ops.import_scene.dff(
                filepath=dff_path,
                files=files,
                directory=os.path.dirname(dff_path),
                filter_glob="*.dff;*.txd;*.col",
                read_mat_split=True,    # force ON
                load_images=True,
                remove_doubles=False,
                connect_bones=False,
                seam_edges=True,
                generate_normals=True,
                use_split_edges=False,
                materials_group=True
            )
        except Exception:
            return False
    return True

def wrap_operator_execute(op_cls):
    """
    Patch GTASA_OT_ImportOne.execute:
      1) Try vendor import through DragonFF (full passthrough). If success => FINISHED.
      2) Else call original importer (fallback). No post-fix transplant here.
    """
    if getattr(op_cls, "_dragonff_wrapped_v2", False):
        return
    _orig = op_cls.execute
    def _wrapped(self, context):
        try:
            model_name = getattr(self, "model_name", "")
            category   = getattr(self, "category", "")
            if vendor_import_via_dragonff(context, model_name, category):
                # We imported everything via DragonFF; report success and skip our pipeline
                self.report({'INFO'}, "Импорт выполнен через DragonFF (материалы/текстуры DragonFF)")
                return {'FINISHED'}
        except Exception:
            pass
        # Fallback to original pipeline
        return _orig(self, context)
    op_cls.execute = _wrapped
    op_cls._dragonff_wrapped_v2 = True
