# SPDX-License-Identifier: GPL-3.0-or-later
ADDON_VERSION = '0.0.1'
bl_info = {
    "name": "ARZ import models",
    "author": "Chel",
    "version": (0, 0, 1),
    "blender": (3, 0, 0),
    "location": "3D View > Sidebar > GTA SA",
    "description": "ахуеть это удобно",
    "category": "Import-Export",
}

import os, sys, types, importlib, tempfile, shutil, bpy, math, statistics
from . import updater_github as _upd
from . import vendor_dragonff_bridge as _dragon_vendor
from bpy.types import Operator, Panel, PropertyGroup, UIList, AddonPreferences
from bpy.props import StringProperty, EnumProperty, BoolProperty, PointerProperty, CollectionProperty, IntProperty

# --- UI tuning constants ---
# Увеличивай значение — поле поиска тянется влево (уменьшается зазор лейбла)
SEARCH_LEFT_GAIN = 0.07  # 0.00..0.30 обычно достаточно

SEARCH_INPUT_UNITS = 10.0  # ширина строки поиска (UI units)


# ---- Custom icon (panel header) ----
try:
    import bpy.utils.previews as _previews_mod
except Exception:
    _previews_mod = None

_custom_previews = None
_custom_icon_name = "gtasa_custom_icon"

def _addon_folder():
    try:
        import os
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        return ""

def _find_icon_file():
    # Prefer PNG (most reliable in Blender). Try icon.png, then any *.png in the folder.
    import os, glob
    root = _addon_folder()
    primary = os.path.join(root, "icon.png")
    if os.path.isfile(primary):
        print("[GTASA] Custom icon: using icon.png at", primary)
        return primary
    # fallback: any png near __init__.py
    pngs = sorted(glob.glob(os.path.join(root, "*.png")))
    if pngs:
        print("[GTASA] Custom icon: using", pngs[0])
        return pngs[0]
    # as a last resort, try common ico name (may fail to load on some builds)
    ico = os.path.join(root, "icon.ico")
    if os.path.isfile(ico):
        print("[GTASA] Custom icon: trying ICO", ico)
        return ico
    print("[GTASA] Custom icon: not found in", root)
    return None

def _load_custom_icon():
    global _custom_previews
    if _previews_mod is None:
        return None
    if _custom_previews is None:
        _custom_previews = _previews_mod.new()
    path = _find_icon_file()
    if not path:
        return None
    try:
        load_path = path
        # If it's an ICO, try to convert to PNG via Blender's image API
        if path.lower().endswith(".ico"):
            try:
                import bpy, os, tempfile
                img = bpy.data.images.load(path)
                tmp_png = os.path.join(tempfile.gettempdir(), "gtasa_custom_icon.png")
                try:
                    # Prefer Image.save if available
                    if hasattr(img, "save"):
                        img.filepath_raw = tmp_png
                        img.file_format = 'PNG'
                        img.save()
                    else:
                        # Fallback: assign and try save_render
                        img.filepath_raw = tmp_png
                        img.file_format = 'PNG'
                        img.save_render(tmp_png)
                except Exception:
                    pass
                if os.path.isfile(tmp_png):
                    load_path = tmp_png
            except Exception as _ico_err:
                print("[GTASA] ICO->PNG convert failed:", _ico_err)
        _custom_previews.load(_custom_icon_name, load_path, 'IMAGE')
        return _custom_previews[_custom_icon_name].icon_id
    except Exception as e:
        print("[GTASA] Preview load failed:", e)
        return None
    if _custom_previews is None:
        _custom_previews = _previews_mod.new()
    path = _find_icon_file()
    if not path:
        return None
    try:
        _custom_previews.load(_custom_icon_name, path, 'IMAGE')
        return _custom_previews[_custom_icon_name].icon_id
    except Exception:
        return None

def _get_custom_icon_id():
    try:
        if _custom_previews and _custom_icon_name in _custom_previews:
            return _custom_previews[_custom_icon_name].icon_id
    except Exception:
        pass
    iid = _load_custom_icon()
    if not iid:
        # one-time hint
        try:
            if not getattr(_get_custom_icon_id, "_warned", False):
                print("[GTASA] Hint: place icon.png next to __init__.py (PNG recommended).")
                _get_custom_icon_id._warned = True
        except Exception:
            pass
    return iid or 0




class GTASA_AddonPrefs(AddonPreferences):
    bl_idname = __package__ or "gta_sa_importer"
    saved_game_root: StringProperty(name="Game Root", subtype='DIR_PATH')
    auto_update: bpy.props.BoolProperty(name="Авто-обновлять при старте", default=False)
    allow_prerelease: bpy.props.BoolProperty(name="Разрешить pre-releases", default=False)
    online_version: bpy.props.StringProperty(name="Онлайн-версия", default="")
    def draw(self, context):
        self.layout.label(text="Откройте панель N → вкладка 'ARZ import models'", icon='INFO')
        box = self.layout.box(); col = box.column(align=True)
        col.label(text="Обновление (GitHub)")
        col.prop(self, "auto_update")
        col.prop(self, "allow_prerelease")
        r = col.row(align=True)
        r.operator("gtasa.check_update", text="Проверить")
        r.operator("gtasa.do_update", text="Обновить")
        if self.online_version:
            col.label(text=f"Доступно: {self.online_version}")

def _lib_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib")

def _ensure_paths_and_pkg():
    lp = _lib_path()
    for p in (os.path.dirname(lp), lp):
        if p and os.path.isdir(p) and p not in sys.path:
            sys.path.insert(0, p)
    if "gtasa_lib" not in sys.modules:
        pkg = types.ModuleType("gtasa_lib")
        pkg.__path__ = [lp]
        sys.modules["gtasa_lib"] = pkg
    return "gtasa_lib"
_PKG = _ensure_paths_and_pkg()

def _import_from_lib(name):
    try:
        return importlib.import_module(f"{_PKG}.{name}")
    except Exception as e:
        print(f"[GTASA] import {_PKG}.{name} failed:", e)
    try:
        return importlib.import_module(name)
    except Exception as e:
        print(f"[GTASA] import {name} failed:", e)
        return None

_imglib = _import_from_lib("img")
_txd_a = _import_from_lib("txd")  # primary
_txd_b = None  # drop demon alt
_dff_mod = _import_from_lib("dff")
for _n in ("native_ps2","native_xbox","native_gc","native_psp","native_wdgl"):
    _import_from_lib(_n)

def _dbg_where(tag, mod):
    try: print(f"[GTASA] Using {tag} from: {getattr(mod, '__file__','<builtin>')}")
    except Exception: pass
if _imglib: _dbg_where("img", _imglib)
if _txd_a: _dbg_where("txd(primary)", _txd_a)
if _txd_b: _dbg_where("txd(alt)", _txd_b)
if _dff_mod: _dbg_where("dff", _dff_mod)

VEH_IMGS_ORDER = ["vehs.img","vehs_1.img","vehs_2.img","vehs_3.img","vehs_4.img","vehs_5.img","vehs_6.img","vehs_7.img"]
ALLMODELS_IMGS = [
    "accessories.img","custom_int.img","cutscene.img","gamemods.img","gta_int.img","gta3.img","gta3_def.img",
    "gta3_def_summer.img","gta3_def2.img","ints.img","map_object.img","peds.img","peds_2.img","pubg.img","tuning.img",
    "vc.img","vehs.img","vehs_1.img","vehs_2.img","vehs_3.img","vehs_4.img","vehs_5.img","vehs_6.img","vehs_7.img",
    "weapons.img"
]
SAMP_EXTRA_IMGS = ["SAMP.img","custom.img"]

def _iter_gta_dat_ides(game_root):
    import os
    dat_rel = os.path.join("data", "gta.dat")
    dat_path = _resolve_ci(game_root, dat_rel, want_dir=False)
    if not dat_path or not os.path.isfile(dat_path):
        return
    with open(dat_path, "rb") as f:
        raw = f.read()
    for enc in ("cp1251", "utf-8", "latin-1"):
        try:
            txt = raw.decode(enc, errors="ignore"); break
        except Exception:
            pass
    else:
        txt = raw.decode("latin-1", errors="ignore")
    for line in txt.splitlines():
        s = line.strip()
        if not s:
            continue
        parts = s.replace("\\", "/").split()
        if len(parts) >= 2 and parts[0].upper() == "IDE":
            rel = parts[1].strip().strip(",;")
            ide_abs = _resolve_ci(game_root, rel, want_dir=False) or _resolve_ci(game_root, os.path.join("data", rel), want_dir=False)
            if ide_abs and ide_abs.lower().endswith(".ide"):
                yield ide_abs

def _read_allmodels_entries(game_root):
    entries = []
    for ide_path in _iter_gta_dat_ides(game_root) or []:
        ide_entries = read_ide_entries(ide_path, mode="objs", single_hash_only=True)
        for e in ide_entries:
            try:
                int(str(e.get("id","")).strip())
            except Exception:
                continue
            mdl = (e.get("model") or "").strip()
            if not mdl:
                continue
            # skip LOD models
            if 'lod' in mdl.lower():
                continue
            entries.append({"id": str(e.get("id","")).strip(),
                            "model": mdl,
                            "txd": (e.get("txd") or "").strip()})
    return entries

def _allmodels_img_paths(game_root):
    models_dir = _resolve_ci(game_root, "models", want_dir=True)
    res = []
    if models_dir:
        for nm in ALLMODELS_IMGS:
            p = _resolve_ci(models_dir, nm, want_dir=False)
            if p:
                res.append(p)
    for nm in SAMP_EXTRA_IMGS:
        p = _resolve_ci(game_root, os.path.join("SAMP", nm), want_dir=False)
        if p:
            res.append(p)
    return res


def _safe_join(*parts): return os.path.normpath(os.path.join(*parts))
def _resolve_ci(base_path, rel_path, want_dir=None):
    if not base_path or not rel_path: return None
    p = _safe_join(base_path, rel_path)
    if ((want_dir is None) and os.path.exists(p)) or (want_dir is True and os.path.isdir(p)) or (want_dir is False and os.path.isfile(p)): return p
    cur = base_path
    parts = os.path.normpath(rel_path).split(os.sep)
    for seg in parts:
        try: entries = os.listdir(cur)
        except FileNotFoundError: return None
        hit = next((e for e in entries if e.lower() == seg.lower()), None)
        if not hit: return None
        cur = os.path.join(cur, hit)
    if want_dir is True and not os.path.isdir(cur): return None
    if want_dir is False and not os.path.isfile(cur): return None
    return cur

def _parse_csv_line(line):
    l = line.strip().split("//",1)[0].strip().rstrip(";")
    parts = [p.strip() for p in l.split(",")]
    return [p for p in parts if p != ""]

def read_ide_entries(ide_path, mode="objs", single_hash_only=False):
    entries = []
    if not os.path.isfile(ide_path): return entries
    with open(ide_path, "rb") as f:
        raw = f.read()
    for enc in ("cp1251", "utf-8", "latin-1"):
        try: txt = raw.decode(enc, errors="ignore"); break
        except Exception: pass
    else: txt = raw.decode("latin-1", errors="ignore")
    lines = txt.splitlines()

    if single_hash_only:
        for ln in lines:
            s = ln.lstrip()
            if not s:
                continue
            if s.startswith("##"):
                continue  # пропускаем двойные комментарии
            if s.startswith("#"):
                content = s[1:].strip()  # срезаем один '#'
            else:
                content = s  # обычная строка без '#'
            parts = _parse_csv_line(content)
            if len(parts) >= 3:
                entries.append({"id": parts[0], "model": parts[1], "txd": parts[2]})
        return entries

    if mode == "skins":
        start_idx = 2068  # 0-based (line 2069)
        for ln in lines[start_idx:]:
            s = ln.lstrip()
            if not s or s.startswith('#'):
                continue
            parts = _parse_csv_line(s)
            if len(parts) >= 3:
                entries.append({"id": parts[0], "model": parts[1], "txd": parts[2]})
        return entries

        return entries

    has_section = any(ln.strip().lower().startswith("objs") for ln in lines) and any(ln.strip().lower()=="end" for ln in lines)
    in_section=False
    vehicles_sections={"cars","car","boats","boat","bikes","bike","planes","plane","helicopters","heli","helicopter","trains","train","trailers","trailer","bmx","quad","vehicle","vehicles","monster","rc","rcbandit","rcbaron"}

    for rawline in lines:
        ln=rawline.strip()
        if not ln: continue
        if ln.startswith("#"):  # skip comments
            continue
        low=ln.lower()
        if has_section:
            if mode=="objs":
                if low.startswith("objs"): in_section=True; continue
            elif mode=="vehicles":
                head=low.split()[0].rstrip(":,")
                if head in vehicles_sections: in_section=True; continue
            if in_section and low=="end": in_section=False; continue
            if not in_section: continue
        parts=_parse_csv_line(ln)
        if len(parts)>=3:
            if mode=="vehicles":
                try:
                    if int(parts[0]) < 612:
                        continue
                except Exception:
                    pass
            entries.append({"id":parts[0],"model":parts[1],"txd":parts[2]})
    if mode == "vehicles":
        start_idx = 226
        for ln in lines[start_idx:]:
            s = ln.strip()
            if not s or s.lstrip().startswith('#'):
                continue
            parts = _parse_csv_line(s)
            if len(parts) >= 3:
                try:
                    if int(parts[0]) < 612:
                        continue
                except Exception:
                    continue
                entries.append({"id": parts[0], "model": parts[1], "txd": parts[2]})
        return entries

    return entries

def _entry_name(entry): return (getattr(entry,"name","") or "").strip()
def _candidates_from_model(model):
    m=(model or "").strip().lower()
    base = m[:-4] if m.endswith(".dff") else m
    return {base, f"{base}.dff"}

# ---- TXD cache ----
_recent_images = {}
_recent_rgba = {}

def _norm(s):
    s = os.path.splitext(s)[0] if s else ""
    return "".join(ch.lower() for ch in s if (ch.isalnum() or ch in "_-"))

def _rgba_to_floats(rgba_seq, w, h):
    if not rgba_seq:
        return [0.0]*(w*h*4)
    try:
        mx = max(rgba_seq[:min(4096, len(rgba_seq))])
    except Exception:
        mx = 255
    is_float = (mx <= 1.001)
    row = w*4
    floats = [0.0]*(w*h*4)
    out_i = 0
    if is_float:
        for y in range(h-1, -1, -1):
            off = y*row
            for x in range(row):
                floats[out_i] = float(rgba_seq[off+x])
                out_i += 1
    else:
        for y in range(h-1, -1, -1):
            off = y*row
            for x in range(row):
                floats[out_i] = float(rgba_seq[off+x])/255.0
                out_i += 1
    return floats

def _assign_pixels(img, floats):
    try:
        img.pixels.foreach_set(floats)
    except Exception:
        try:
            img.pixels[:] = floats
        except Exception:
            pass

def _finalize_image(img, pack):
    try:
        img.alpha_mode='STRAIGHT'
        try: img.colorspace_settings.name='sRGB'
        except Exception: pass
        img.update()
        if hasattr(img, "gl_free"):
            try: img.gl_free()
            except Exception: pass
        if hasattr(img, "gl_load"):
            try: img.gl_load()
            except Exception: pass
        if pack:
            try: img.pack()
            except Exception: pass
    except Exception:
        pass

def _to_bytes_0_255(seq):
    if isinstance(seq, (bytes, bytearray)): return bytes(seq)
    if not seq: return b''
    try:
        mx = max(seq[:min(4096, len(seq))])
    except Exception:
        mx = 255
    is_float = (mx <= 1.001)
    if is_float:
        return bytes(int(max(0, min(255, round(v*255.0)))) for v in seq[:])
    else:
        return bytes(int(max(0, min(255, int(v)))) for v in seq[:])

def _permute(raw, perm):
    out = bytearray(len(raw))
    for i in range(len(raw)//4):
        base=i*4
        out[base+0]=raw[base+perm[0]]
        out[base+1]=raw[base+perm[1]]
        out[base+2]=raw[base+perm[2]]
        out[base+3]=raw[base+perm[3]]
    return bytes(out)

def _score_rgb(raw):
    npx = max(1, len(raw)//4)
    npx = min(npx, 4096)
    R = [raw[i*4+0] for i in range(npx)]
    G = [raw[i*4+1] for i in range(npx)]
    B = [raw[i*4+2] for i in range(npx)]
    mean = (sum(R)+sum(G)+sum(B))/(255.0*3.0*npx)
    def _std(xs):
        if len(xs)<2: return 0.0
        m = sum(xs)/len(xs)
        v = sum((x-m)*(x-m) for x in xs)/len(xs)
        return (v**0.5)/255.0
    var = (_std(R)+_std(G)+_std(B))/3.0
    return mean + 0.5*var, mean, var


def _fix_length_rgba(name, seq, w, h):
    """Ensure a proper RGBA byte buffer length == w*h*4. Accepts floats [0..1] or bytes.
    Handles RGB, L, LA and weird sizes; fills alpha with 255; logs diagnostics."""
    raw = _to_bytes_0_255(seq)
    exp = w*h*4
    n = len(raw)
    if n == exp:
        return raw, "RGBA"
    def rep_rgba_from_rgb(raw3):
        out = bytearray(exp)
        for i in range(w*h):
            out[i*4+0]=raw3[i*3+0]
            out[i*4+1]=raw3[i*3+1]
            out[i*4+2]=raw3[i*3+2]
            out[i*4+3]=255
        return bytes(out)
    def rep_rgba_from_l(raw1):
        out = bytearray(exp)
        for i in range(w*h):
            v=raw1[i]
            out[i*4+0]=v; out[i*4+1]=v; out[i*4+2]=v; out[i*4+3]=255
        return bytes(out)
    def rep_rgba_from_la(raw2):
        out = bytearray(exp)
        for i in range(w*h):
            l=raw2[i*2+0]; a=raw2[i*2+1]
            out[i*4+0]=l; out[i*4+1]=l; out[i*4+2]=l; out[i*4+3]=a
        return bytes(out)
    mode="unknown"
    if n == w*h*3:
        raw = rep_rgba_from_rgb(raw); mode="RGB->RGBA"
    elif n == w*h:
        raw = rep_rgba_from_l(raw); mode="L->RGBA"
    elif n == w*h*2:
        raw = rep_rgba_from_la(raw); mode="LA->RGBA"
    else:
        # try to cut or pad
        out = bytearray(exp)
        m = min(exp, n)
        out[:m] = raw[:m]
        if exp>n:
            for i in range((exp//4)):
                out[i*4+3]=255
        raw = bytes(out); mode=f"padded({n}->{exp})"
    # If alpha all zero -> set to 255
    alphas = raw[3::4]
    if all(a==0 for a in alphas):
        raw = bytearray(raw)
        for i in range(w*h):
            raw[i*4+3]=255
        raw = bytes(raw)
        mode += "+fixA0"
    print(f"[GTASA] Buffer fix for {name}: n={n} exp={exp} mode={mode}")
    return raw, mode

def _reorder_from_tag_to_rgba(raw_bytes, tag):
    # raw_bytes is a bytes-like object in the detected 'tag' order; convert to RGBA
    if tag == "RGBA":
        return raw_bytes
    order = {
        "BGRA": (2,1,0,3),
        "ARGB": (1,2,3,0),
        "ABGR": (3,2,1,0),
    }.get(tag)
    if order is None:
        return raw_bytes
    return _permute(raw_bytes, order)
def _choose_best_rgba_order(name, seq):
    # Trust backend decoder (gtasa_lib.txd) to return RGBA already.
    raw = _to_bytes_0_255(seq)
    mean = 0.0; var = 0.0
    try:
        _, mean, var = _score_rgb(raw)
    except Exception:
        pass
    print(f"[GTASA] Channel order for {name}: assume RGBA (mean={mean:.4f}, var={var:.4f})")
    return raw, "RGBA", (mean, var)
def _alpha_to_rgb(seq):
    raw = _to_bytes_0_255(seq)
    n = len(raw)//4
    out = bytearray(len(raw))
    for i in range(n):
        a = raw[i*4+3]
        out[i*4+0]=a; out[i*4+1]=a; out[i*4+2]=a; out[i*4+3]=255
    return bytes(out)


def _create_image_exact(name, rgba_seq, w, h, pack):
    """Create or overwrite bpy.data.images[name] as 8-bit RGBA and write pixels reliably."""
    import bpy, array
    if name in bpy.data.images:
        img = bpy.data.images[name]
        try:
            img.scale(w, h)
        except Exception:
            pass
    else:
        img = bpy.data.images.new(name=name, width=w, height=h, alpha=True, float_buffer=False)

    # Ensure byte -> float in [0..1]
    if rgba_seq and isinstance(rgba_seq[0], (bytes, bytearray)):
        rgba = rgba_seq
    else:
        rgba = bytes(rgba_seq or [])
    if len(rgba) != w*h*4:
        # pad or trim to exact size
        rgba = (rgba + bytes(w*h*4))[:w*h*4]

    # Convert to float list
    floats = [c/255.0 for c in rgba]
    try:
        img.pixels = floats
    except Exception:
        # Fallback via foreach_set for Blender quirks
        img.pixels.foreach_set(floats)

    if pack:
        try:
            img.pack()
        except Exception:
            pass
    return img
def _list_all_imgs(models_dir):
    try:
        entries = os.listdir(models_dir)
    except Exception:
        return []
    priority = [
        "accessories.img", "gamemods.img",
        "gta3.img", "gta_int.img", "player.img",
        "cutscene.img", "generic.img", "props.img"
    ]
    lower_map = {e.lower(): e for e in entries if e.lower().endswith(".img")}
    ordered = [lower_map[p] for p in priority if p in lower_map]
    rest = sorted([v for k,v in lower_map.items() if k not in priority])
    for r in rest:
        if r not in ordered:
            ordered.append(r)
    return ordered

def _find_in_any_img(models_dir, model):
    all_imgs = _list_all_imgs(models_dir)
    if not all_imgs: return (None, -1, "")
    return _find_in_imgs(models_dir, all_imgs, model)
def _find_in_imgs(models_dir, img_names, model):
    import os
    if _imglib is None: return (None,-1,"")
    cands=_candidates_from_model(model)
    for nm in img_names:
        # support absolute paths (e.g., <root>\SAMP\SAMP.img)
        if os.path.isabs(nm) or nm.startswith(("/", "\\")):
            p = nm if os.path.isfile(nm) else None
        else:
            p=_resolve_ci(models_dir, nm, want_dir=False)
        if not p:
            continue
        try:
            with _imglib.img.open(p) as imh:
                find_idx = getattr(imh, "find_entry_idx", None)
                if callable(find_idx):
                    for cand in cands:
                        idx = find_idx(cand)
                        if idx >= 0:
                            entry = getattr(imh, "directory_entries", [])[idx]
                            return p, idx, _entry_name(entry)
                for idx,entry in enumerate(getattr(imh,"directory_entries",[]) or []):
                    if ((_entry_name(entry) or "").lower()) in cands:
                        return p, idx, _entry_name(entry)
        except FileNotFoundError as e:
            # Sidecar .dir missing: skip (archive likely not VER2 and lacks index file)
            if ".dir" in str(e).lower():
                continue
            continue
        except Exception as e:
            try:
                print("[GTASA] IMG open error for", p, ":", repr(e))
            except Exception:
                pass
            continue
    return (None,-1,"")
    cands=_candidates_from_model(model)
    for nm in img_names:
        p=_resolve_ci(models_dir, nm, want_dir=False)
        if not p: continue
        with _imglib.img.open(p) as imh:
            for idx,entry in enumerate(getattr(imh,"directory_entries",[]) or []):
                if ((_entry_name(entry) or "").lower()) in cands:
                    return p, idx, _entry_name(entry)
    return (None,-1,"")

def _decode_one_backend(mod, txd_path, pack, skip_mipmaps, replace_zero_only=False, allowed_names=None):
    if mod is None:
        return 0, {}
    created = 0
    info = {}
    backend = getattr(mod, "__name__", "unknown")
    try:
        txd_obj = mod.txd()
        txd_obj.load_file(txd_path)
    except Exception as e:
        print(f"[GTASA] {backend} load failed:", e)
        return 0, {}

    def add_image(name, rgba, w, h, level):
        nonlocal created, info
        raw = _to_bytes_0_255(rgba)
        bs = sum(raw[:min(4096, len(raw))])
        key = _norm(name)

        # Filtering/replace-zero-only logic
        if replace_zero_only:
            if allowed_names and _equiv_name(name) not in {_equiv_name(n) for n in allowed_names}:
                return
            # if we already recorded a non-zero bytesum, skip replacing
            prev = info.get(key)
            if prev and prev[2] > 0:
                return

        _create_image_exact(name, raw, w, h, pack)
        info[key] = (w, h, bs, level, backend)
        created += 1

    _allowed = {_equiv_name(n) for n in allowed_names} if allowed_names else None

    
    images_attr = getattr(txd_obj, "images", None)

    def iter_images(images_attr):
        # Yield (name, [mip_images]) regardless of layout
        if isinstance(images_attr, dict):
            for k, v in images_attr.items():
                yield k, list(v) if isinstance(v, (list, tuple)) else [v]
        elif isinstance(images_attr, (list, tuple)):
            for el in images_attr:
                if isinstance(el, tuple) and len(el) >= 2:
                    name, v = el[0], el[1]
                    yield name, list(v) if isinstance(v, (list, tuple)) else [v]
                else:
                    name = getattr(el, "name", None) or getattr(el, "texname", None)
                    v = getattr(el, "mipmaps", None) or getattr(el, "images", None) or [el]
                    yield name, list(v) if isinstance(v, (list, tuple)) else [v]
        else:
            return

    for name, imgs in iter_images(images_attr):
        if not name:
            continue
        if _allowed is not None and _equiv_name(name) not in _allowed:
            continue
        chosen = None
        for level, im in enumerate(imgs):
            rgba = getattr(im, "to_rgba", lambda: None)()
            if rgba:
                w = getattr(im, "width", 0); h = getattr(im, "height", 0)
                chosen = (level, rgba, w, h)
                break
        if not chosen and imgs:
            im = imgs[0]
            rgba = getattr(im, "to_rgba", lambda: None)()
            if rgba:
                w = getattr(im, "width", 0); h = getattr(im, "height", 0)
                chosen = (0, rgba, w, h)
        if chosen:
            add_image(name, chosen[1], chosen[2], chosen[3], chosen[0])

    return created, info
def _decode_txd_multi(txd_path, pack=True, skip_mipmaps=True, allowed_names=None):
    """Decode TXD via primary backend, optionally re-decoding zero-bytesum textures via alt backend."""
    import os
    total = 0
    used_info = {}

    n1, info1 = _decode_one_backend(_txd_a, txd_path, pack, skip_mipmaps, replace_zero_only=False, allowed_names=allowed_names)
    total += n1
    for k, v in (info1 or {}).items():
        used_info[k] = v

    zero_names = [k for k, (w, h, bs, lv, bk) in (info1 or {}).items() if bs == 0]

    if zero_names and _txd_b:
        # decode only the zero-bytesum textures with alt backend
        n2, info2 = _decode_one_backend(_txd_b, txd_path, pack, skip_mipmaps, replace_zero_only=True, allowed_names=zero_names)
        total += n2
        for k, v in (info2 or {}).items():
            used_info[k] = v

    print(f"[GTASA] TXD decoded (multi): {total} image writes from {os.path.basename(txd_path)}")
    try:
        for name, (w, h, bs, lv, bk) in used_info.items():
            print(f"[GTASA] TXD tex: {name} {w}x{h} level={lv} backend={bk} bytesum={bs}")
    except Exception:
        pass

    # return total writes and the set of backends used (for logging)
    return total, (set(v[-1] for v in used_info.values()) or {'none'})
def _fill_existing_images_from_cache(pack=True):
    for img in list(bpy.data.images):
        try: w, h = img.size[0], img.size[1]
        except Exception: continue
        if w==0 or h==0 or (w==1 and h==1):
            key = _norm(img.name)
            if key in _recent_rgba:
                W,H,rgba = _recent_rgba[key]
                try:
                    img.scale(W, H)
                    floats = _rgba_to_floats(rgba, W, H)
                    _assign_pixels(img, floats)
                except Exception: pass
                _finalize_image(img, pack)

def _largest_decoded_image():
    best=None; best_area=-1
    for img in set(_recent_images.values()):
        try: w,h = img.size[:]
        except Exception: continue
        area = int(w*h)
        if area>best_area:
            best, best_area = img, area
    return best


def _equiv_name(n:str):
    try:
        n = (n or "").strip()
        n = n.rsplit(".", 1)[0]
        return n.lower()
    except Exception:
        return (n or "").lower()
# Node & UV helpers
def _ensure_principled(mat):
    mat.use_nodes=True
    nt = mat.node_tree
    bsdf = next((n for n in nt.nodes if n.type=='BSDF_PRINCIPLED'), None)
    if not bsdf:
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    out = next((n for n in nt.nodes if n.type=='OUTPUT_MATERIAL'), None)
    if not out:
        out = nt.nodes.new("ShaderNodeOutputMaterial")
    for link in list(nt.links):
        if link.to_node==out and link.to_socket==out.inputs.get('Surface'):
            nt.links.remove(link)
    nt.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    return nt, bsdf, out

def _bind_image_to_material(mat, img, uv_name=None):
    if img is None:
        return  # Read Material Split: leave pure BSDF when texture missing
    nt, bsdf, out = _ensure_principled(mat)
    tex_node = next((n for n in nt.nodes if n.type=='TEX_IMAGE'), None)
    if not tex_node:
        tex_node = nt.nodes.new("ShaderNodeTexImage")
    tex_node.image = img
    # UVMap node не нужен — Blender подставит активный UV сам.
    # Base Color link
    if not any(l.to_node==bsdf and l.to_socket.name=='Base Color' for l in nt.links):
        nt.links.new(tex_node.outputs['Color'], bsdf.inputs['Base Color'])
    # Alpha link (DragonFF behavior)
    try:
        if not any(l.to_node==bsdf and l.to_socket.name=='Alpha' for l in nt.links):
            nt.links.new(tex_node.outputs.get('Alpha'), bsdf.inputs.get('Alpha'))
        # Enable alpha-friendly blend for cutouts; keep OPAQUE as default if no alpha used
        mat.blend_method = getattr(mat, 'blend_method', 'OPAQUE') or 'OPAQUE'
        if hasattr(mat, "shadow_method"):
            mat.shadow_method = getattr(mat, 'shadow_method', 'OPAQUE') or 'OPAQUE'
    except Exception:
        pass
    try:
        w,h = img.size[:]
        px = list(img.pixels[:64]) if w*h>0 else []
        meanR = sum(px[::4])/max(1, len(px[::4]))
        print(f"[GTASA] Bound image info: {img.name} size={w}x{h} sample_meanR={meanR:.4f} uv='{uv_name or '<auto>'}'")
    except Exception: pass
    try:
        img.update()
        if hasattr(img, "gl_free"): img.gl_free()
        if hasattr(img, "gl_load"): img.gl_load()
    except Exception: pass

def _purge_texture_nodes(mat):
    """Remove TEX_IMAGE nodes and ensure BSDF -> Output is connected (DragonFF-like when no texture)."""
    nt, bsdf, out = _ensure_principled(mat)
    for n in list(nt.nodes):
        if getattr(n, "type", "") == "TEX_IMAGE":
            nt.nodes.remove(n)
    for link in list(nt.links):
        if link.to_node==out and link.to_socket==out.inputs.get('Surface'):
            nt.links.remove(link)
    try:
        nt.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    except Exception:
        pass
    # Make sure material is non-transparent if no texture (DragonFF-like)
    try:
        mat.blend_method = 'OPAQUE'
        if hasattr(mat, 'shadow_method'):
            mat.shadow_method = 'OPAQUE'
    except Exception:
        pass


def _match_image_by_name(name_candidates):
    for cand in name_candidates:
        key = _norm(cand)
        im = _recent_images.get(key) or bpy.data.images.get(cand) or bpy.data.images.get(cand.lower()) or bpy.data.images.get(cand.upper())
        if im and im.size[0] > 1 and im.size[1] > 1:
            return im
    return None



def _pick_image_for_material(mat, tex_names):
    """DragonFF-like binding with minimal aliases:
    - Exact DFF texture name match to material name wins.
    - primary/secondary: never create a TEX_IMAGE.
    - Otherwise try small alias mapping (int/badges/wheel/glass/lights) only if the target texture exists.
    - If still not found, return None (no texture node).
    """
    import re, os
    if not mat:
        return None
    norm = lambda s: _norm(s or "")
    tnames = list(tex_names or [])
    names_norm = {norm(n): n for n in tnames}
    mname_raw = getattr(mat, "name", "") or ""
    mname = norm(mname_raw)

    # 1) exact match to a DFF texture name
    if mname in names_norm:
        im = _match_image_by_name([names_norm[mname]])
        if im:
            return im

    # 2) DragonFF rule: primary/secondary never get a TEX_IMAGE node
    if mname.startswith("primary") or mname.startswith("secondary"):
        return None

    # 3) if the material already has a TEX_IMAGE node with an image that is in DFF tex names, keep it
    if getattr(mat, "use_nodes", False) and getattr(mat, "node_tree", None):
        for n in mat.node_tree.nodes:
            if getattr(n, "type", "") == "TEX_IMAGE" and getattr(n, "image", None):
                iname = getattr(n.image, "name", "")
                if norm(iname) in names_norm:
                    im = _match_image_by_name([names_norm[norm(iname)]])
                    if im:
                        return im

    # 4) minimal alias mapping (matches DragonFF behavior for common GTA SA car materials)
    base = ""
    m = re.match(r"[A-Za-z_]+", mname_raw)
    if m:
        base = m.group(0).lower()

    def choose_first_present(candidates):
        ordered = [c for c in candidates if norm(c) in names_norm]
        if not ordered:
            # allow 'contains' match: find any tex that contains token
            lowered = [x.lower() for x in tnames]
            for token in candidates:
                token_l = token.lower()
                for idx, full in enumerate(lowered):
                    if token_l in full:
                        im = _match_image_by_name([tnames[idx]])
                        if im:
                            return im
            return None
        # exact name candidates first
        return _match_image_by_name([names_norm[norm(ordered[0])]])

    # alias buckets
    if base in ("int", "interior", "dash", "dashboard"):
        im = choose_first_present(["gtsamg_int", "gtsamg_dash", "_int", "_dash"])
        if im: return im

    if "badge" in base or "badges" in mname_raw.lower():
        im = choose_first_present(["gtsamg_badges", "badges"])
        if im: return im

    if "wheel" in mname_raw.lower() or base == "wheel":
        im = choose_first_present(["gtsamg_wheel", "wheel"])
        if im: return im

    # glass group (windscreen, glassall, headglass, reargl, turntrans)
    if any(k in mname_raw.lower() for k in ("glass", "wind", "windscreen", "glassall", "reargl", "headglass", "turntrans")):
        im = choose_first_present(["wnd", "wndfrl", "wndrrl", "wnd_rr", "chrome_glass", "vehicleshatter128", "shatter"])
        if im: return im

    # lights group
    if any(k in mname_raw.lower() for k in ("light", "headl", "taillight", "rlight", "trnlght", "tlght")):
        im = choose_first_present(["vehiclelights128", "rlight", "trnlght_lf", "trnlght_rf", "trdbrklight"])
        if im: return im

    # do NOT fallback to generic body textures — leave no node to match DragonFF behavior
    return None


def _build_dff_material_texture_map(dff_path):
    names_by_index = {}
    masks_by_index = {}
    if not _dff_mod:
        return names_by_index, masks_by_index
    try:
        d = _dff_mod.dff(); d.load_file(dff_path)
        for geom in getattr(d, "geometry_list", []) or []:
            mats = getattr(geom, "materials", []) or []
            for idx, mat in enumerate(mats):
                texname = None; maskname = None
                for tex in getattr(mat, "textures", []) or []:
                    nm = (getattr(tex, "name", "") or "").strip()
                    mk = (getattr(tex, "mask", "") or "").strip()
                    if nm and texname is None: texname = nm
                    if nm and mk and maskname is None: maskname = mk
                names_by_index[idx] = texname
                masks_by_index[idx] = maskname
    except Exception as e:
        print("[GTASA] DFF mat->tex map failed:", e)
    return names_by_index, masks_by_index
def _collect_dff_texture_names(dff_path):
    names=set(); masks={}
    if not _dff_mod: return names, masks
    try:
        d = _dff_mod.dff(); d.load_file(dff_path)
        for geom in getattr(d, "geometry_list", []) or []:
            for mat in getattr(geom, "materials", []) or []:
                for tex in getattr(mat, "textures", []) or []:
                    name=(getattr(tex,"name","") or "").strip()
                    mask=(getattr(tex,"mask","") or "").strip()
                    if name: names.add(name)
                    if name and mask: masks[name]=mask
    except Exception as e:
        print("[GTASA] DFF parse names failed:", e)
    return names, masks

# ----------------- Data & UI -----------------
class GTASA_ModelItem(bpy.types.PropertyGroup):
    id_str: StringProperty(name="ID")
    model: StringProperty(name="Model")
    txd: StringProperty(name="TXD")
    category: StringProperty(name="Category")

def _on_tab_update(self, context):
    try: bpy.ops.gtasa.refresh()
    except Exception: pass

def _on_search_update(self, context):
    try: bpy.ops.gtasa.refresh()
    except Exception: pass

class GTASA_Settings(bpy.types.PropertyGroup):
    game_root: StringProperty(name="Путь к игре", subtype='DIR_PATH')
    filter_query: StringProperty(name="", default="", update=_on_search_update, options={'TEXTEDIT_UPDATE'})

    # Режим поиска/отображения: по DFF или по ID
    def _on_search_mode_update(self, context):
        try: bpy.ops.gtasa.refresh()
        except Exception: pass
    search_mode: EnumProperty(
        name="Фильтр",
        items=(('DFF','Поиск по dff','Названия заменяются на dff'),('ID','Поиск по id','Названия заменяются на id')),
        default='DFF',
        update=_on_search_mode_update
    )
    current_tab: EnumProperty(
        name="Категория",
        items=(('ACCESSORIES','Accessories',''),('SKINS','Skins',''),('VEHICLES','Vehicles',''),('WEAPONS','Weapon',''),('GAMEMODS','GameMods',''),('ALL','All model','')),
        default='ACCESSORIES',
        update=_on_tab_update
    )
    load_txd: BoolProperty(name="Загружать TXD", default=True)
    txd_pack: BoolProperty(name="Паковать изображения", default=True)
    skip_mipmaps: BoolProperty(name="Пропускать мипмапы", default=True)

class GTASA_UL_ModelList(UIList):
    def draw_filter(self, context, layout):
        return

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        s = context.scene.gtasa_settings
        label_text = item.model or "<unknown>"
        try:
            if getattr(s, "search_mode", "DFF") == 'ID':
                label_text = (item.id_str or "").strip() or "<unknown>"
        except Exception:
            pass
        row.label(text=label_text)


        # делаем кнопку "Импорт" чуть шире текста
        btn = row.row(align=True)
        try:
            # если доступно (Blender 4.x) — задаём ширину строки в UI-юнитах
            btn.ui_units_x = 3.5   # подбери 5–7 по вкусу
        except Exception:
            pass

        # добавляем «невидимые» figure spaces, чтобы кнопка стала шире
        PAD = "\u2007" * 0      # 2–3 штуки = тонкая подгонка
        op = btn.operator("gtasa.import_one", text=f"Импорт{PAD}")
        op.model_name = item.model
        op.category  = item.category


class GTASA_OT_SettingsPopup(Operator):
    bl_idname = "gtasa.show_settings"
    bl_label = "Настройки импорта"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        s = context.scene.gtasa_settings
        layout = self.layout
        col = layout.column(align=True)
        if hasattr(s, "load_txd"): col.prop(s, "load_txd")
        if hasattr(s, "txd_pack"): col.prop(s, "txd_pack")
        if hasattr(s, "skip_mipmaps"): col.prop(s, "skip_mipmaps")

    def execute(self, context):
        return {'FINISHED'}



class GTASA_MT_FilterMenu(bpy.types.Menu):
    bl_idname = "GTASA_MT_FilterMenu"
    bl_label = "Фильтр"

    def draw(self, context):
        layout = self.layout
        s = context.scene.gtasa_settings
        # Две прямые кнопки (взаимоисключающие)
        layout.prop_enum(s, 'search_mode', 'ID')
        layout.prop_enum(s, 'search_mode', 'DFF')

class GTASA_PT_Main(Panel):
    def draw_header(self, context):
        try:
            iid = _get_custom_icon_id()
            if iid:
                self.layout.label(text="", icon_value=iid)
        except Exception:
            pass

    bl_label=" Import models"; bl_space_type='VIEW_3D'; bl_region_type='UI'; bl_category="ARZ import models"
    def draw(self, context):
        s=context.scene.gtasa_settings; col=self.layout.column(align=True)
        # --- ШАПКА: слева компактный box (кнопка + статус), справа ⚙️ ---
        header = col.row(align=True)

        # статус
        ok = (s.game_root and os.path.isdir(s.game_root) and os.path.isdir(os.path.join(s.game_root, "models")))
        status_text = "Путь указан " if ok else "Путь не указан"

        # прикидываем нужную ширину слева в пикселях и переводим в долю от ширины региона
        # база под кнопку ~28px + ~11px на символ + небольшой запас
        approx_px = 12 * len(status_text)
        region_w  = max(1, context.region.width)
        factor    = max(0.08, min(0.45, approx_px / region_w))  # левая часть займет ~нужную ширину

        split = header.split(factor=factor, align=True)
        left  = split.row(align=True)    # левая узкая часть
        right = split.row(align=True)    # правая часть (заполняет остальное)

        # сам компактный box
        box = left.box()
        r   = box.row(align=True)
        r.operator("gtasa.browse_root", icon="FILE_FOLDER", text="")
        r.label(text=status_text, icon=('CHECKMARK' if ok else 'CANCEL'))

        # ⚙️ справа, вне бокса
        
        right.alignment = 'RIGHT'
        # Кнопка фильтра (слева от шестерёнки)
        try:
            right.menu('GTASA_MT_FilterMenu', text='', icon='FILTER')
        except Exception:
            pass
        # Кнопка настроек
        right.operator('gtasa.show_settings', text='', icon='PREFERENCES')

        col.separator()
        # --- конец шапки ---

        row=col.row(align=True); row.prop(s,"current_tab", expand=True)
        sr = col.row(align=True)
        factor = max(0.05, 0.18 - SEARCH_LEFT_GAIN)
        split = sr.split(factor=factor, align=True)
        split.label(text="Поиск:")
        field = split.row(align=True)
        try:
            field.ui_units_x = SEARCH_INPUT_UNITS
        except Exception:
            pass
        field.prop(s, "filter_query", text="")
        col.template_list("GTASA_UL_ModelList","",context.scene,"gtasa_items",context.scene,"gtasa_list_index",rows=14)

# -------- safe operator helpers --------
def _try_call(idname, **kwargs):
    try:
        cat, name = idname.split('.', 1)
        cat_obj = getattr(bpy.ops, cat, None)
        if cat_obj is None:
            raise AttributeError("category missing")
        fn = getattr(cat_obj, name, None)
        if fn is None:
            raise AttributeError("operator missing")
        res = fn(**kwargs)
        ok = isinstance(res, set) and (('FINISHED' in res) or ('EXEC_FINISHED' in res))
        print(f"[GTASA] Call {idname} -> {res}")
        return ok
    except Exception as e:
        print(f"[GTASA] Call {idname} failed:", e)
        return False

def _import_dff_via_ops(filepath, txd_files=None, force_read_mat_split=False, load_images=True):
    """
    Try a list of operators to import DFF.
    If DragonFF is used, we pass the DFF + TXD via 'files' and force read_mat_split.
    Returns the idname string that succeeded, or None.
    """
    candidates = [
        "dragonff.import_dff",
        "import_scene.rw_dff",
        "import_scene.dff",
        "io_scene_dff.import_dff",
        "io_import_scene.rw_dff",
    ]
    import os, bpy
    for idn in candidates:
        try:
            cat, name = idn.split('.', 1)
            cat_obj = getattr(bpy.ops, cat, None)
            if cat_obj is None:
                raise AttributeError("category missing")
            fn = getattr(cat_obj, name, None)
            if fn is None:
                raise AttributeError("operator missing")
            kwargs = {"filepath": filepath}
            if idn == "import_scene.dff":
                # Pass both DFF and TXD so DragonFF can load textures from local folder
                files = [{"name": os.path.basename(filepath)}]
                if txd_files:
                    for p in txd_files:
                        if p and os.path.isfile(p):
                            files.append({"name": os.path.basename(p)})
                kwargs.update({
                    "files": files,
                    "directory": os.path.dirname(filepath),
                    "filter_glob": "*.dff;*.txd;*.col",
                    "load_images": bool(load_images),
                    "read_mat_split": True if force_read_mat_split else False,
                })
            res = fn(**kwargs)
            ok = isinstance(res, set) and (('FINISHED' in res) or ('EXEC_FINISHED' in res))
            print(f"[GTASA] Call {idn} -> {res}")
            if ok:
                return idn
        except Exception as e:
            print(f"[GTASA] Call {idn} failed:", e)
            continue
    return None


def _pick_uv_layer(me, preferred=("Float2","UVMap","UVMap.001")):
    """Return name of a UV layer to use. Prefer names from 'preferred' or first existing."""
    if not me or not getattr(me, "uv_layers", None): 
        return None
    for name in preferred:
        if name in me.uv_layers:
            return name
    if len(me.uv_layers) > 0:
        return me.uv_layers[0].name
    return None

def _flip_v_for_layer(me, uv_name):
    """Flip V (v = 1 - v) for given UV layer name in mesh data."""
    if not me or not getattr(me, "uv_layers", None): 
        return
    uv_layer = me.uv_layers.get(uv_name) if hasattr(me.uv_layers, "get") else None
    if uv_layer is None and len(me.uv_layers) > 0:
        # fallback to active
        uv_layer = me.uv_layers.active
    if uv_layer is None:
        return
    try:
        for li in uv_layer.data:
            li.uv.y = 1.0 - li.uv.y
        me.update()
    except Exception as e:
        print(f"[GTASA] UV flip failed for {getattr(me, 'name', '?')}: {e!r}")

def _ensure_vehicle_txd(txd_names, img_sources):
    """Append 'vehicle.txd' to txd_names if found in any provided IMG sources and not already present."""
    try:
        name = 'vehicle.txd'
        if any(n.lower() == name for n in (txd_names or [])):
            return txd_names
        # img_sources is a list of (img_path, index_obj) or similar; we only need to check via our IMG API if available
        try:
            from gtasa_lib import img as _img
        except Exception:
            try:
                import gtasa_lib.img as _img
            except Exception:
                _img = None
        if _img is None:
            return txd_names
        for src in (img_sources or []):
            img_path = src[0] if isinstance(src, (list, tuple)) and src else src
            try:
                arc = _img.ImageArchive(img_path)
                if arc.has_entry(name):
                    txd_names = list(txd_names or []) + [name]

                    return txd_names
            except Exception:
                continue
        return txd_names
    except Exception:
        return txd_names
# ----------------- Operators -----------------
class GTASA_OT_BrowseRoot(Operator):
    bl_idname="gtasa.browse_root"; bl_label="Browse"
    bl_description = "Указать путь к игре"
    directory: StringProperty(subtype='DIR_PATH')
    def execute(self, context):
        s=context.scene.gtasa_settings; s.game_root=self.directory
        try: bpy.ops.gtasa.refresh()
        except Exception: pass
        try:
            prefs_wrap = bpy.context.preferences.addons.get(__package__)
            if prefs_wrap:
                prefs_wrap.preferences.saved_game_root = context.scene.gtasa_settings.game_root
        except Exception:
            pass

        return {'FINISHED'}
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self); return {'RUNNING_MODAL'}

class GTASA_OT_RefreshList(Operator):
    bl_idname="gtasa.refresh"; bl_label="Обновить список"
    def execute(self, context):
        s=context.scene.gtasa_settings; coll=context.scene.gtasa_items; coll.clear()
        root=s.game_root
        if not root or not os.path.isdir(root):
            self.report({'ERROR'},"Путь к игре не задан"); return {'CANCELLED'}
        tab=s.current_tab
        if tab=='ACCESSORIES':
            ide_rel=os.path.join('data','maps','accessories','accessories.ide'); category='accessories'; mode='objs'; single_hash=True
        elif tab=='GAMEMODS':
            ide_rel=os.path.join('data','maps','gamemods','gamemods.ide'); category='gamemods'; mode='objs'; single_hash=False
        elif tab=='WEAPONS':
            ide_rel=os.path.join('data','weapons.ide'); category='weapons'; mode='objs'; single_hash=False
        elif tab=='SKINS':
            ide_rel=os.path.join('SAMP','SAMP.ide'); category='skins'; mode='skins'; single_hash=False
        elif tab=='ALL':
            category='all'; mode='objs'; single_hash=True
            entries = _read_allmodels_entries(root)
            q=(s.filter_query or "").lower().strip(); seen=set()
            if not entries:
                self.report({'ERROR'}, "gta.dat не найден или пуст"); return {'CANCELLED'}
        else:
            ide_rel=os.path.join('data','vehicles.ide'); category='vehicles'; mode='vehicles'; single_hash=False
        if tab!='ALL':
            ide_path=_resolve_ci(root, ide_rel, want_dir=False)
            if not ide_path: self.report({'ERROR'}, f"IDE не найден: {ide_rel}"); return {'CANCELLED'}
            entries=read_ide_entries(ide_path, mode=mode, single_hash_only=single_hash)
        q=(s.filter_query or "").lower().strip(); seen=set()
        for e in entries:
            mdl=(e.get("model") or "").strip(); txd=(e.get("txd") or "").strip()
            if not mdl: 
                continue
            mode = getattr(s, "search_mode", "DFF")
            if q:
                if mode == 'ID':
                    if q not in (e.get("id") or "").strip().lower():
                        continue
                else:
                    if q not in mdl.lower():
                        continue
            key=mdl.lower()
            if key in seen: 
                continue
            it=coll.add()
            it.id_str=(e.get("id") or "").strip()
            it.model=mdl
            it.txd=txd
            it.category=category
            seen.add(key)
        if len(coll)==0: 
            self.report({'INFO'},"Список пуст — проверьте вкладку/поиск/IDE")
        return {'FINISHED'}
class GTASA_OT_ImportOne(Operator):
    bl_idname="gtasa.import_one"; bl_label="Импортировать модель"; bl_options={'REGISTER','UNDO'}
    model_name: StringProperty(); category: StringProperty()

    def execute(self, context):
        s=context.scene.gtasa_settings; root=s.game_root
        if not root or not os.path.isdir(root):
            self.report({'ERROR'},"Путь к игре не задан"); return {'CANCELLED'}
        items=[it for it in context.scene.gtasa_items if it.model==self.model_name and it.category==self.category]
        if not items: self.report({'ERROR'},"Модель не найдена в списке"); return {'CANCELLED'}
        item=items[0]

        models_dir=_resolve_ci(root,"models", want_dir=True)
        if not models_dir: self.report({'ERROR'},"Папка models не найдена"); return {'CANCELLED'}

        if item.category=="accessories":
            img_names=["accessories.img","SAMP/SAMP.img"]
        elif item.category=="gamemods":
            img_names=["gamemods.img","accessories.img"]
        elif item.category=="skins":
            img_names=["peds.img","peds_2.img"]
        elif item.category=="weapons":
            img_names=["weapons.img"]
        else:
            img_names=VEH_IMGS_ORDER
        if item.category=="all":
            img_names = _allmodels_img_paths(root)

        img_path, dff_idx, dff_real = _find_in_imgs(models_dir, img_names, item.model)
        if not img_path:
            self.report({'ERROR'}, f"{item.model}.dff не найден строго в: {', '.join(img_names)}")
        
        try:
            import bpy
            for obj in bpy.context.selected_objects:
                if getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'data', None):
                    me = obj.data
                    uv_name = _pick_uv_layer(me)
                    if uv_name:
                        _flip_v_for_layer(me, uv_name)
                        try:
                            me.uv_layers.active = me.uv_layers[uv_name]
                        except Exception:
                            pass
        except Exception as e:
            print(f"[GTASA] UV post-fix error: {e!r}")

        
        if _imglib is None:
            self.report({'ERROR'}, "Модуль IMG не найден — не могу извлечь из .img"); return {'CANCELLED'}

        tmp_dir=tempfile.mkdtemp(prefix="gtasa_import_")
        out_dff=None; txd_path=None; out_txd_vehicle=None
        extra_txd_path=None
        try:
            # --- Read DFF from the chosen archive ---
            with _imglib.img.open(img_path) as imh:
                name, data = imh.read_entry(dff_idx)
                out_dff = os.path.join(tmp_dir, name.strip()); open(out_dff, "wb").write(data)
        
            if s.load_txd:
                # --- Build list of archives to scan for TXDs ---
                    img_scan_paths = []
                    if img_path and os.path.isfile(img_path):
                        img_scan_paths.append(img_path)
                    # All-model: include all known archives
                    if item.category in ("all","vehicles","accessories","gamemods"):
                        for pth in _allmodels_img_paths(root):
                            if pth not in img_scan_paths:
                                img_scan_paths.append(pth)
                    # Ensure SAMP/custom too
                    custom_img = _resolve_ci(root, os.path.join("SAMP","custom.img"), want_dir=False)
                    if custom_img and custom_img not in img_scan_paths:
                        img_scan_paths.append(custom_img)
                    # --- Resolve which TXDs to load ---
                    txd_key = (item.txd or item.model).strip().lower()
                    txd_cands = {txd_key, f"{txd_key}.txd"}
        
                    # Optional extra TXD for balloon texts (append, do not replace)
                    extra_txd_key = "balloon_texts1" if txd_key == "balloon_texts" else None
        
                    # Search TXDs across all candidate archives
                    for arc_path in img_scan_paths:
                        try:
                            with _imglib.img.open(arc_path) as imh:
                                # primary
                                if not txd_path:
                                    for entry_list_name in ("directory_entries", "entries"):
                                        for tidx, entry in enumerate(getattr(imh, entry_list_name, []) or []):
                                            nm = (getattr(entry, "name", "") or "").strip().lower()
                                            if nm in txd_cands:
                                                name, data = imh.read_entry(tidx)
                                                txd_path = os.path.join(tmp_dir, name.strip()); open(txd_path, "wb").write(data)
                                                break
                                        if txd_path:
                                            break
                                # extra
                                if extra_txd_key and not extra_txd_path:
                                    extra_cands = {extra_txd_key, f"{extra_txd_key}.txd"}
                                    for entry_list_name in ("directory_entries", "entries"):
                                        for tidx2, entry2 in enumerate(getattr(imh, entry_list_name, []) or []):
                                            nm2 = (getattr(entry2, "name", "") or "").strip().lower()
                                            if nm2 in extra_cands:
                                                name2, data2 = imh.read_entry(tidx2)
                                                extra_txd_path = os.path.join(tmp_dir, name2.strip()); open(extra_txd_path, "wb").write(data2)
                                                break
                                        if extra_txd_path:
                                            break
                        except Exception:
                            pass  # try next archive
        
                    # Fallback to models/generic for any missing TXDs
                    if txd_path is None and item.category!="gamemods":
                        gen = _resolve_ci(models_dir, os.path.join("generic", f"{txd_key}.txd"), want_dir=False)
                        if gen and os.path.isfile(gen):
                            txd_path = os.path.join(tmp_dir, os.path.basename(gen)); shutil.copy2(gen, txd_path)
                            print(f"[GTASA] Fallback TXD from models/generic: {os.path.basename(gen)}")
                    if extra_txd_key and extra_txd_path is None:
                        gen2 = _resolve_ci(models_dir, os.path.join("generic", f"{extra_txd_key}.txd"), want_dir=False)
                        if gen2 and os.path.isfile(gen2):
                            extra_txd_path = os.path.join(tmp_dir, os.path.basename(gen2)); shutil.copy2(gen2, extra_txd_path)
                            print(f"[GTASA] Fallback extra TXD from models/generic: {os.path.basename(gen2)}")
        
        
        except Exception as e:
            print("[GTASA] IMG read error:", e)
                            # Attach item_number.txd from models/txd for GameMods
        itm_num = _resolve_ci(models_dir, os.path.join("txd","item_number.txd"), want_dir=False)
        if itm_num and os.path.isfile(itm_num):
            extra_itemnum_txd_path = os.path.join(tmp_dir, os.path.basename(itm_num)); shutil.copy2(itm_num, extra_itemnum_txd_path)
            print("[GTASA] Added models/txd/item_number.txd for GameMods")

        if s.load_txd and item.category=="gamemods" and txd_path is None and not extra_itemnum_txd_path:
            self.report({'ERROR'}, f"TXD '{(item.txd or item.model)}' не найден в gamemods.img и accessories.img");
            return {'CANCELLED'}

        if s.load_txd and item.category in ("vehicles","all"):
            veh_txd = _resolve_ci(models_dir, os.path.join("generic","vehicle.txd"), want_dir=False)
            if veh_txd and os.path.isfile(veh_txd):
                out_txd_vehicle = os.path.join(tmp_dir, os.path.basename(veh_txd)); shutil.copy2(veh_txd, out_txd_vehicle)
                print("[GTASA] Added generic/vehicle.txd for Vehicles")

        tex_names, tex_masks = _collect_dff_texture_names(out_dff)
        mat_tex_by_idx, mat_mask_by_idx = _build_dff_material_texture_map(out_dff)
        # --- Respect 'Загружать TXD' toggle: if off, skip any TXD extraction/decoding entirely ---
        if not s.load_txd:
            _recent_images.clear(); _recent_rgba.clear()
            dec_total = 0; decoders = set()
            out_txd_vehicle = None; txd_path = None; extra_txd_path = None
        
        if tex_names: print("[GTASA] DFF texture names:", ", ".join(sorted(tex_names)))

        _recent_images.clear(); _recent_rgba.clear()
        dec_total=0; decoders=set()
        _allowed = set(tex_names) | set(tex_masks.values())
        if out_txd_vehicle:
            n, backs = _decode_txd_multi(out_txd_vehicle, pack=s.txd_pack, skip_mipmaps=s.skip_mipmaps, allowed_names=_allowed); dec_total+=n; decoders |= backs
        if txd_path:
            n, backs = _decode_txd_multi(txd_path, pack=s.txd_pack, skip_mipmaps=s.skip_mipmaps, allowed_names=_allowed); dec_total+=n; decoders |= backs
        if extra_txd_path:
            n2, backs2 = _decode_txd_multi(extra_txd_path, pack=s.txd_pack, skip_mipmaps=s.skip_mipmaps, allowed_names=_allowed); dec_total+=n2; decoders |= backs2
        if extra_itemnum_txd_path:
            n3, backs3 = _decode_txd_multi(extra_itemnum_txd_path, pack=s.txd_pack, skip_mipmaps=s.skip_mipmaps, allowed_names=None); dec_total+=n3; decoders |= backs3
        _fill_existing_images_from_cache(pack=s.txd_pack)

        before_objs=set(bpy.data.objects)
        idn = _import_dff_via_ops(out_dff, txd_files=([p for p in [out_txd_vehicle, txd_path, extra_txd_path] if p] if s.load_txd else []), force_read_mat_split=True, load_images=s.load_txd)
        ok = bool(idn)
        after_objs=set(bpy.data.objects)
        new_objs=[o for o in after_objs-before_objs]

        if not ok:
            self.report({'ERROR'}, "Не найден ни один DFF-импортёр (dragonff/import_scene.rw_dff/import_scene.dff). Установите DragonFF или RW DFF.")
            return {'CANCELLED'}
        # If TXD loading is disabled, ensure no Image nodes exist on new objects (pure BSDF)
        if not s.load_txd:
            try:
                for obj in new_objs:
                    mats = getattr(getattr(obj, 'data', None), 'materials', None)
                    if not mats:
                        continue
                    for mat in mats:
                        if mat:
                            _purge_texture_nodes(mat)
            except Exception as _purge_err:
                print("[GTASA] Purge images (load_txd=OFF) error:", _purge_err)
    
        
        if idn == 'import_scene.dff':
            # Пропускаем ручной бинд, DragonFF уже назначил материалы/текстуры
            try:
                shutil.rmtree(tmp_dir, ignore_errors=True)
            except Exception:
                pass
            self.report({'INFO'}, f"Импортировано: {item.model}")
            return {'FINISHED'}
    

        for obj in new_objs:
            me = getattr(obj, 'data', None)
            uv_name = None
            if me and getattr(me, 'uv_layers', None):
                try:
                    uv_name = me.uv_layers.active.name
                except Exception:
                    uv_name = None
            _layers_len = (len(me.uv_layers) if (me and getattr(me, 'uv_layers', None)) else 0)
            print("[GTASA] UV:", getattr(obj,'name','<noobj>'), "layers=", _layers_len, "active='{}'".format(uv_name or "<none>"))
            mats = getattr(obj.data, 'materials', None)
            if not mats:
                continue
            
            for slot_idx, mat in enumerate(mats):
                if not mat:
                    continue
                if not s.load_txd:
                    _purge_texture_nodes(mat)
                    try:
                        print(f"[GTASA] Bind skipped (TXD disabled) for {obj.name}/{getattr(mat, 'name', '<mat>')}")
                    except Exception:
                        pass
                    continue
                # Prefer exact DFF material->texture mapping by material index (DragonFF-like)
                want = (mat_tex_by_idx.get(slot_idx) or mat_mask_by_idx.get(slot_idx))
                img = None
                if want:
                    img = _match_image_by_name([want])
                if not img:
                    # Heuristic fallback by known names groups (glass/lights), still limited to decoded set
                    img = _pick_image_for_material(mat, list(tex_names))
                if img:
                    _bind_image_to_material(mat, img, uv_name=uv_name)
                    try:
                        print(f"[GTASA] Bind: {obj.name}/{mat.name} <- {img.name} (uv='{uv_name or '<none>'}')")
                    except Exception:
                        pass
                else:
                    _purge_texture_nodes(mat)
                    try:
                        print(f"[GTASA] Bind: no image for {obj.name}/{mat.name}")
                    except Exception:
                        pass
        info_mod = ', '.join(sorted(decoders)) or 'none'
        self.report({'INFO'}, f"Импортировано: {item.model} (TXD images: {dec_total}; decoders: {info_mod})")
        try: shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception: pass
        
        try:
            import bpy
            for obj in bpy.context.selected_objects:
                if getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'data', None):
                    me = obj.data
                    uv_name = _pick_uv_layer(me)
                    if uv_name:
                        _flip_v_for_layer(me, uv_name)
                        try:
                            me.uv_layers.active = me.uv_layers[uv_name]
                        except Exception:
                            pass
        except Exception as e:
            print(f"[GTASA] UV post-fix error: {e!r}")
        
        try:
            import bpy
            for obj in bpy.context.selected_objects:
                if getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'data', None):
                    me = obj.data
                    uv_name = _pick_uv_layer(me)
                    if uv_name:
                        _flip_v_for_layer(me, uv_name)
                        try:
                            me.uv_layers.active = me.uv_layers[uv_name]
                        except Exception:
                            pass
        except Exception as e:
            print(f"[GTASA] UV post-fix error: {e!r}")


        return {'FINISHED'}

classes=(GTASA_ModelItem, GTASA_Settings, GTASA_UL_ModelList, GTASA_PT_Main, GTASA_OT_BrowseRoot, GTASA_OT_RefreshList, GTASA_OT_ImportOne, GTASA_OT_SettingsPopup, GTASA_AddonPrefs, GTASA_MT_FilterMenu)


def _gtasa_initial_refresh():
    import bpy, os
    try:
        s = bpy.context.scene.gtasa_settings
        prefs_wrap = bpy.context.preferences.addons.get(__package__)
        if prefs_wrap:
            prefs = prefs_wrap.preferences
            if prefs.saved_game_root and os.path.isdir(prefs.saved_game_root):
                if not s.game_root:
                    s.game_root = prefs.saved_game_root
        coll = getattr(bpy.context.scene, "gtasa_items", None)
        if s.game_root and os.path.isdir(s.game_root) and (coll is None or len(coll) == 0):
            try: bpy.ops.gtasa.refresh()
            except Exception: pass
    except Exception:
        pass
    return None


def register():
    try:
        bpy.utils.register_class(GTASA_OT_CheckUpdate)
        bpy.utils.register_class(GTASA_OT_DoUpdate)
    except Exception:
        pass
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        if getattr(prefs, 'auto_update', False):
            bpy.ops.gtasa.check_update('INVOKE_DEFAULT')
    except Exception:
        pass
    try:
        _load_custom_icon()
    except Exception:
        pass
    try:
        bpy.app.timers.register(_gtasa_initial_refresh, first_interval=0.3)
    except Exception:
        pass
    try:
        from .vendor_dragonff_bridge import wrap_operator_execute
        # Monkeypatch import operator so DragonFF curates materials
        wrap_operator_execute(GTASA_OT_ImportOne)
    except Exception:
        pass

    print(f"[GTASA] gta_sa_importer v{ADDON_VERSION} loaded")
    for c in classes: bpy.utils.register_class(c)
    bpy.types.Scene.gtasa_settings=PointerProperty(type=GTASA_Settings)
    bpy.types.Scene.gtasa_items=CollectionProperty(type=GTASA_ModelItem)
    bpy.types.Scene.gtasa_list_index=IntProperty(default=0)

def unregister():
    try:
        bpy.utils.unregister_class(GTASA_OT_DoUpdate)
    except Exception:
        pass
    try:
        bpy.utils.unregister_class(GTASA_OT_CheckUpdate)
    except Exception:
        pass
    global _custom_previews
    try:
        if _custom_previews is not None:
            _custom_previews.close()
    except Exception:
        pass
    _custom_previews = None
    for c in reversed(classes):
        try: bpy.utils.unregister_class(c)
        except Exception: pass
    for attr in ("gtasa_settings","gtasa_items","gtasa_list_index"):
        if hasattr(bpy.types.Scene, attr):
            try: delattr(bpy.types.Scene, attr)
            except Exception: pass

if __name__=="__main__":
    register()
class GTASA_OT_CheckUpdate(bpy.types.Operator):
    bl_idname = "gtasa.check_update"; bl_label = "Check for update"; bl_options = {'INTERNAL'}
    def execute(self, ctx):
        try:
            prefs = ctx.preferences.addons[__package__].preferences
        except Exception:
            self.report({'ERROR'}, "Prefs unavailable")
            return {'CANCELLED'}
        cur = tuple(bl_info.get("version") or (0,0,0))
        info = _upd.check_latest(cur, allow_prerelease=bool(getattr(prefs, "allow_prerelease", False)))
        if info.get("has_update"):
            v = ".".join(map(str, info.get("online_version") or ()))
            prefs.online_version = v or ""
            self.report({'INFO'}, f"Найдена версия {v}")
        else:
            prefs.online_version = ""
            self.report({'INFO'}, "Обновлений нет")
        return {'FINISHED'}

class GTASA_OT_DoUpdate(bpy.types.Operator):
    bl_idname = "gtasa.do_update"; bl_label = "Update addon"; bl_options = {'INTERNAL'}
    def execute(self, ctx):
        try:
            prefs = ctx.preferences.addons[__package__].preferences
        except Exception:
            self.report({'ERROR'}, "Prefs unavailable")
            return {'CANCELLED'}
        cur = tuple(bl_info.get("version") or (0,0,0))
        info = _upd.check_latest(cur, allow_prerelease=bool(getattr(prefs, "allow_prerelease", False)))
        if not info.get("has_update"):
            self.report({'INFO'}, "Нет доступного обновления")
            return {'CANCELLED'}
        asset = info.get("asset")
        ok = _upd.perform_update(asset)
        if ok:
            prefs.online_version = ""
            self.report({'INFO'}, "Аддон обновлён до последней версии")
            return {'FINISHED'}
        self.report({'ERROR'}, "Не удалось обновить")
        return {'CANCELLED'}
