
# Integrated auto-material binder for GTA SA DFF imports
# Emulates DragonFF's behavior for materials: only add texture node if the texture exists,
# handle glass alpha, prefer UV layer "Float2", and skip collision/shadow meshes.

import bpy
import re

_GLASS_HINTS = ("glass", "wnd", "wind", "light", "shatter", "plate", "glass.", "headglass")
_SKIP_OBJ_SUBSTR = ("ColMesh", "ColSphere", "ShadowMesh")
_PRIMARY_LIKE = ("primary", "secondary", "generic", "chassis")
_WHEEL_HINT = ("wheel",)
_INT_HINT = ("int", "dashboard", "dash")
_BADGES_HINT = ("badges",)
_LIGHTS_HINT = ("light", "taillight", "headlight", "vehiclelights")
_ENV_HINT = ("env",)

# Textures often found in logs; we map material substrings -> texture name preference
_SUBSTR_RULES = [
    (re.compile(r"(glass|wnd|wind)", re.I), "wnd"),
    (re.compile(r"(int|dashboard|dash)", re.I), "gtsamg_int"),
    (re.compile(r"(wheel)", re.I), "gtsamg_wheel"),
    (re.compile(r"(badge)", re.I), "gtsamg_badges"),
    (re.compile(r"(head\s*light|front\s*light)", re.I), "vehiclelights128"),
    (re.compile(r"(tail\s*light|rear\s*light)", re.I), "vehiclelights128"),
    (re.compile(r"(env)", re.I), "xvehicleenv128"),
    (re.compile(r"(chrome)", re.I), "chrome64"),
    (re.compile(r"(carbon)", re.I), "carbon"),
    (re.compile(r"(grill)", re.I), "grill"),
    (re.compile(r"(plastic)", re.I), "plastic"),
    (re.compile(r"(vehiclegeneric|primary|secondary|generic|chassis)", re.I), "vehiclegeneric256"),
]

def _find_uv_or_set(obj):
    if not obj.data or not hasattr(obj.data, "uv_layers"):
        return
    uvs = obj.data.uv_layers
    if "Float2" in uvs:
        uvs.active = uvs.get("Float2")
    elif len(uvs) > 0:
        uvs.active = uvs[0]

def _image_by_name_like(name: str):
    # Try exact, then casefold, then startswith/contains heuristics
    if not name:
        return None
    cand = bpy.data.images.get(name)
    if cand: return cand
    low = name.casefold()
    for img in bpy.data.images:
        iname = img.name
        if iname == name:
            return img
        if iname.casefold() == low:
            return img
    # startswith / contains
    for img in bpy.data.images:
        iname = img.name.casefold()
        if iname.startswith(low) or low in iname:
            return img
    return None

def _guess_tex_for_material(mat_name: str):
    # Try rules in order
    for rx, tex in _SUBSTR_RULES:
        if rx.search(mat_name or ""):
            img = _image_by_name_like(tex)
            if img:
                return img
    # fallback: try to find any image whose name appears inside material name
    tokens = re.split(r"[^a-zA-Z0-9_]+", (mat_name or ""))
    tokens = [t for t in tokens if t]
    for t in tokens:
        img = _image_by_name_like(t)
        if img:
            return img
    return None

def _has_alpha(img):
    try:
        return bool(getattr(img, "has_data", True) and getattr(img, "depth", 32) in (32, 64) or getattr(img, "channels", 4) >= 4 or img.use_alpha)
    except:
        return True

def _ensure_nodes(mat):
    if not mat.use_nodes:
        mat.use_nodes = True
    nt = mat.node_tree
    if nt is None:
        return None, None
    nodes = nt.nodes
    links = nt.links
    # find or create
    bsdf = nodes.get("Principled BSDF")
    if not bsdf:
        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.location = (0,0)
    out = None
    for n in nodes:
        if n.type == 'OUTPUT_MATERIAL':
            out = n
            break
    if not out:
        out = nodes.new("ShaderNodeOutputMaterial")
        out.location = (300, 0)
    # link if not linked
    if not any(l.to_node == out for l in links):
        links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return bsdf, out

def ensure_principled_setup(mat):
    _ensure_nodes(mat)

def guess_is_glass_mat(mat_name: str):
    name = (mat_name or "").casefold()
    return any(h in name for h in _GLASS_HINTS)

def _clear_existing_tex_nodes(nt):
    # remove only image texture nodes we created before (safe heuristic)
    for n in list(nt.nodes):
        if n.type == 'TEX_IMAGE':
            nt.nodes.remove(n)

def _bind_image_to_mat(mat, img, glass_hint=False):
    bsdf, out = _ensure_nodes(mat)
    if not bsdf:
        return

    nt = mat.node_tree
    links = nt.links

    # remove previous texture nodes (avoid multiple stacking)
    _clear_existing_tex_nodes(nt)

    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    tex.label = img.name
    tex.location = (-300, 0)

    # base color
    try:
        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    except:
        pass

    # alpha handling
    use_alpha = False
    if _has_alpha(img) or glass_hint:
        try:
            links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
            use_alpha = True
        except:
            pass

    # Set blend method if needed
    if use_alpha or glass_hint:
        mat.blend_method = 'BLEND'
        mat.shadow_method = 'HASHED'
        # reduce roughness for glass-like
        if glass_hint:
            try:
                bsdf.inputs["Roughness"].default_value = 0.1
                bsdf.inputs["Transmission"].default_value = 0.0
            except:
                pass
    else:
        mat.blend_method = 'OPAQUE'
        mat.shadow_method = 'OPAQUE'


def apply_gtasa_materials(context=None):
    print("[GTASA] Auto-material binding started")
    ctx = context or bpy.context

    # Build a quick index of available images by name (diagnostic)
    img_names = [img.name for img in bpy.data.images]
    print("[GTASA] Available images:", img_names)

    for obj in list(bpy.context.scene.objects):
        if obj.type != 'MESH':
            continue
        name_cf = obj.name.casefold()
        if any(s.casefold() in name_cf for s in _SKIP_OBJ_SUBSTR):
            print(f"[GTASA] Skip collision/shadow object: {{obj.name}}")
            continue

        _find_uv_or_set(obj)

        me = obj.data
        if not me.materials:
            continue

        for slot in obj.material_slots:
            mat = slot.material
            if not mat:
                continue

            mat_name = mat.name
            glass_hint = guess_is_glass_mat(mat_name)

            # Always ensure at least BSDF + Output nodes exist
            ensure_principled_setup(mat)

            # Try to find a matching image for this material
            img = _guess_tex_for_material(mat_name)

            # If it's a primary/secondary/generic and no image present -> do NOT add texture node (dragonff-like)
            prim_like = any(s in mat_name.casefold() for s in _PRIMARY_LIKE)

            if img is None and prim_like:
                # leave BSDF only
                print(f"[GTASA] No image for {mat_name} (primary/generic-like) -> leave BSDF only")
                mat.blend_method = 'OPAQUE'
                mat.shadow_method = 'OPAQUE'
                continue

            if img is None:
                # still none: try to sniff from faces' image assignment (if any baked)
                # (Often DFF import doesn't set per-face images; skipping)
                print(f"[GTASA] No image found for {mat_name} -> leaving BSDF only")
                mat.blend_method = 'OPAQUE'
                mat.shadow_method = 'OPAQUE'
                continue

            # If image exists -> bind
            _bind_image_to_mat(mat, img, glass_hint=glass_hint)

    print("[GTASA] Auto-material binding done")
