# GTA DragonFF - Blender scripts to edit basic GTA formats
# Enhanced IMG reader: supports IMG v2 ("VER2" header) without .dir and keeps backward compatibility.
# Adds small robustness improvements (case-insensitive lookup, safe name decoding).

import os
from dataclasses import dataclass
from struct import unpack, unpack_from

#######################################################
@dataclass
class DirectoryEntry:
    offset: int
    size: int
    name: str

    #######################################################
    @classmethod
    def read_from_memory(cls, data, offset=0):
        # IMG directory entries are 32 bytes: uint32 offset, uint32 size, char name[24]
        off, size, rawname = unpack_from("II24s", data, offset)
        # decode name safely, strip after NULs and whitespace
        name = rawname.split(b'\0', 1)[0].decode('utf-8', errors='ignore').strip()
        return cls(off, size, name)

#######################################################
class img:

    #######################################################
    def load_dir_memory(self, data):
        data_len = len(data)
        # directory is a packed array of 32-byte entries
        for pos in range(0, data_len, 32):
            entry = DirectoryEntry.read_from_memory(data, pos)
            if not entry.name:
                # guard against trailing garbage
                continue
            self.directory_entries.append(entry)

    #######################################################
    def clear(self):
        self.directory_entries:list[DirectoryEntry] = []
        self.entry_idx = 0

    #######################################################
    @classmethod
    def open(cls, filename):
        file = open(filename, mode='rb')
        self = cls(file)

        # Try to detect embedded directory (IMG v2)
        head = file.read(8)
        if len(head) < 8:
            file.close()
            raise IOError("Invalid IMG file (too short): %r" % (filename,))

        magic, entries_num = unpack("4sI", head)

        if magic == b"VER2":
            # Sanity clamp
            if entries_num < 0 or entries_num > 10_000_000:
                file.close()
                raise IOError("Suspicious entry count in IMG: %d" % entries_num)
            dir_bytes_len = entries_num * 32
            dir_data = file.read(dir_bytes_len)
            if len(dir_data) != dir_bytes_len:
                file.close()
                raise IOError("Incomplete IMG directory table in: %r" % (filename,))
            self.load_dir_memory(dir_data)
        else:
            # Fallback to external .dir sidecar
            dir_filename = os.path.splitext(filename)[0] + '.dir'
            if not os.path.isfile(dir_filename):
                # Older/other variants without 'VER2' but also without .dir are unsupported here.
                # Fail gracefully with a clear message.
                file.close()
                raise FileNotFoundError(f"IMG index not found. Neither embedded 'VER2' header nor sidecar .dir present for: {filename}")
            with open(dir_filename, mode='rb') as dir_file:
                dir_data = dir_file.read()
            self.load_dir_memory(dir_data)

        # Reset
        file.seek(0, os.SEEK_SET)
        return self

    #######################################################
    def close(self):
        if getattr(self, "_file", None) and not self._file.closed:
            self._file.close()

    #######################################################
    def read_entry(self, entry_idx=None):
        if entry_idx is None:
            entry_idx = self.entry_idx

        if 0 <= entry_idx < len(self.directory_entries):
            entry = self.directory_entries[entry_idx]
            # Offsets/sizes are in 2048-byte sectors
            self._file.seek(entry.offset * 2048, os.SEEK_SET)
            return entry.name, self._file.read(entry.size * 2048)

        return "", b""

    #######################################################
    def find_entry_idx(self, name: str):
        # Case-insensitive match; some archives store upper-case names
        name_ci = name.lower()
        return next(
            (idx for idx, entry in enumerate(self.directory_entries) if entry.name.lower() == name_ci),
            -1
        )

    #######################################################
    def __init__(self, file):
        self._file = file
        self.clear()

    #######################################################
    def __enter__(self):
        return self

    #######################################################
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    #######################################################
    def __del__(self):
        self.close()
